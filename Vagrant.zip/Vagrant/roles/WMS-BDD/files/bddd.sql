-- On s'assure d'être sur la bonne base
CREATE DATABASE IF NOT EXISTS EOL_DB;
USE EOL_DB;

-- 1. Table OS
CREATE TABLE os (
    id INT AUTO_INCREMENT PRIMARY KEY, -- Utilisation de INT
    nom VARCHAR(100) NOT NULL UNIQUE,
);

-- 2. Table Version
CREATE TABLE version (
    id INT AUTO_INCREMENT PRIMARY KEY,
    version VARCHAR(50) NOT NULL,
    version_detail VARCHAR(50),
    total VARCHAR(50),
    ip VARCHAR(50),
    date_eol DATE,
    date_scan_eol TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut_eol VARCHAR(20),
    os_id INT NOT NULL,                -- Doit être strictement INT comme au-dessus
    
    CONSTRAINT fk_os
        FOREIGN KEY (os_id) 
        REFERENCES os(id)
        ON DELETE CASCADE
);
