### Installation Vagrant : 

#### `installer vagrant` via leur site officiel 

https://developer.hashicorp.com/vagrant/install

Laisser l'installation se faire, redémarrer le poste

ensuite ouvrir un cmd et lancer cette commande : 
```powershell
vagrant plugin install vagrant-vmware-desktop
```
et juste après lancer le `vagrant-vmware-utility.msi`


Vagrant sera bien installé, et pour lancer le setup des machines en automatique, se rendre dans le dossier avec tous les fichiers comme le Vagrantfile etc, 
`clic-droit --> Ouvrir dans le terminal et taper la commande : `
```powershell
vagrant up
```

Toutes les machines vont s'installer une à une, si vous voulez avoir les vm sur votre VMware

se rendre sur l'appli `VMware Workstation Pro --> Clic droit --> Ouvrir`

se rendre dans le dossier :
`Vagrant --> .vagrant --> machines --> {machine_au_choix} --> vmware_desktop --> {id_machine} --> {machine_au_choix}.vmx`

(les identifiants + Mot de passe sont spécifiés dans le .env du **`Vagrant.zip`**)
