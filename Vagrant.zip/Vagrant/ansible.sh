#!/bin/bash

# 1. Mise à jour et installation d'Ansible et des outils réseau
echo "--- Installation d'Ansible et dépendances ---"
sudo apt-get update -y
sudo apt-get install -y ansible python3-pip sshpass

# 2. Installation de pywinrm (Indispensable pour piloter Windows depuis Linux)
# On utilise --break-system-packages car Ubuntu 24.04 protège son Python système
echo "--- Installation des modules Python pour Windows ---"
sudo pip3 install pywinrm --break-system-packages

# 3. Localisation des fichiers (Gestion de la magie du transfert Vagrant)
echo "--- Vérification de l'emplacement des fichiers ---"
# Vagrant dépose les fichiers dans /home/vagrant par défaut
BASE_DIR="/home/vagrant"

if [ -f "$BASE_DIR/playbook.yml" ]; then
    echo "Fichiers trouvés dans $BASE_DIR"
    cd $BASE_DIR
else
    echo "ERREUR : Fichiers non trouvés. Vérifiez le provision file dans le Vagrantfile."
    exit 1
fi

# 4. Configuration d'Ansible (Éviter les blocages interactifs)
# On désactive la vérification des clés SSH pour que le script ne s'arrête pas
export ANSIBLE_HOST_KEY_CHECKING=False

# 5. Lancement du Playbook
echo "--- Lancement du Playbook Ansible ---"
# On utilise l'inventaire copié pour cibler les IPs 192.168.10.x
ansible-playbook -i inventory/hosts playbook.yml